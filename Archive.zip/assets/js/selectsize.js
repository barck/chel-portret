	$(function(){
		$('.30x40').click(function(){
			$(".razmer [value='3040']").attr("selected","selected");
		});
		$('.40x60').click(function(){
			$(".razmer [value='4060']").attr("selected","selected");
		});
		$('.50x70').click(function(){
			$(".razmer [value='5070']").attr("selected","selected");
		});
		$('.60x80').click(function(){
			$(".razmer [value='6080']").attr("selected","selected");
		});
		$('.70x90').click(function(){
			$(".razmer [value='7090']").attr("selected","selected");
		});
		$('.90x120').click(function(){
			$(".razmer [value='90120']").attr("selected","selected");
		});

	});